<?php

date_default_timezone_set("Asia/Ho_Chi_Minh");

$name = "dokthancau";


exec("ffmpeg.exe");
exec("ffmpeg -loop 1 -i dokthancau.jpg -i dokthancau.mp3 -c:v libx264 -tune stillimage -c:a aac -b:a 192k -pix_fmt yuv420p -shortest out.mp4");

$timestamp = date('H:i:s');
echo $timestamp;