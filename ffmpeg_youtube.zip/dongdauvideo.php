<?php

date_default_timezone_set("Asia/Ho_Chi_Minh");

$name = "tt5";

exec("ffmpeg.exe");
//exec("ffmpeg -r 1 -loop 1 -i data/".$name.".jpg -i data/".$name.".mp3 -acodec copy -r 1 -shortest -vf scale=1280:720 output/".$name.".mp4");
//exec("ffmpeg -i 20210315_214655.mp4 -i audio.mp3 -map 0:v -map 1:a -c:v copy -shortest outputx.mp4");
//exec("ffmpeg -y -i Dewdrops_1.mp4 -stream_loop -1 -i rain.mp3 -map 0:v -map 1:a -c:v copy -shortest rain.mp4");
//exec("ffmpeg  -stream_loop -1 -i input.mp4 -i input.mp3 -shortest -map 0:v:0 -map 1:a:0 -y out.mp4");
/*loop video cho den khi ket thuc mp3*/
//exec("ffmpeg -stream_loop -1 -i Dewdrops_1.mp4 -i rain.mp3 -map 0:v -map 1:a -c:v copy -shortest rain.mp4");
//exec("ffmpeg -i Dewdrops_1.mp4 -vf \"drawtext=text='Mr Rain':x=w-tw-30:y=30:fontsize=24:fontcolor=white\" -c:v copy outdongdau.mp4");
exec("ffmpeg -y -i Untitled.mp4 -vf \"drawtext='fontsize=70':fontcolor=white:fontfile=Roboto-Regular.ttf:text='Rain on Window':x=w-tw-30:y=30\" -codec:a copy haha2.mp4");

$timestamp = date('H:i:s');
echo $timestamp;