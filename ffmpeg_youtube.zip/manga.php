<?php

date_default_timezone_set("Asia/Ho_Chi_Minh");

$name = "mtk14";

exec("ffmpeg.exe");
//exec("ffmpeg -r 1 -loop 1 -i data/".$name.".jpg -i data/".$name.".mp3 -acodec copy -r 1 -shortest -vf scale=1280:720 output/".$name.".mp4");
exec("ffmpeg -framerate 1/5 -i data/image-%03d.jpg output.mp4");

$timestamp = date('H:i:s');
echo $timestamp;