<?php

// reset = 0
$file = fopen("data/count.txt", "w");
fwrite($file, 0);
fclose($file);

// xoa text
$files = glob("{text/*,edit/*}", GLOB_BRACE);
foreach ($files as $file) {
	if (is_file($file)) {
		unlink($file);
	}
}

copy('data/thongtin.txt', 'edit/0000.txt');

header('Location: get.php');
exit('ok');