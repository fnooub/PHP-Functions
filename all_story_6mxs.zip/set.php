<?php

include "functions.php";

$id = (int) get_var('link');

$single_curl = single_curl('http://m.6mxs.com/novel.asp?id=' . $id);

$raw_links = get_row('<div class="sso_a">', '</div>', $single_curl);

$links = get_links($raw_links);

// thong tin
$tieude = get_row('<span class="main">\s*', '\s*</span>', $single_curl);
$mota = get_row('<div class="novelinfo">\s*', '\s*</div>', $single_curl);
$mota = wp_strip_all_tags($mota, true);

$thongtin = "$tieude\n\n$mota";

file_put_contents('data/thongtin.txt', $thongtin);
file_put_contents('data/links.txt', json_encode($links));
file_put_contents('data/id.txt', $id);

echo "<p>chờ...</p>";
header("Refresh:2; url=reset.php");