<?php

include "functions.php";

$files = glob("text/*");

foreach ($files as $key => $file) {
	$noidung = file_get_contents($file);

	// edit
	$noidung = wp_strip_all_tags($noidung);

	$noidung = preg_replace('/document.{1,3}write\(\'/', '', $noidung);
	$noidung = str_replace("');", "", $noidung);

	// <p><br>
	$noidung = preg_replace('/(< *\/? *p *>|< *br *\/? *>)/', "\n", $noidung);

	$pathname = 'edit/' . d04(($key+1)) . '.txt';
	file_put_contents($pathname, $noidung);

}

header('Location: merge.php');