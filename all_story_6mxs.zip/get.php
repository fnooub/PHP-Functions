<?php

include "functions.php";


// get data
$urls = json_decode(file_get_contents("data/links.txt"), true);
$total = count($urls);
$count = file_get_contents("data/count.txt");

if ($count == $total) {
	header("Refresh:2; url=edit.php");
	echo "<p>chờ...</p>";
	exit;
}


// giay
header("Refresh: 0;");

$dem = $count+1;

// url
$link = $urls[$count];


// get content & save
$single_curl = single_curl($link);

$noidung = get_row('<div class="novelinfvie">', '</div>', $single_curl);

// luu noi dung
$d04 = sprintf( "%04d", $dem );
$filename = "text/$d04.txt";
file_put_contents($filename, $noidung);

// tang them +1 vao file count.txt
$file = fopen("data/count.txt", "w");
fwrite($file, $dem);
fclose($file);

// show
echo "$dem/$total";
