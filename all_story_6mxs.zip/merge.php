<?php

include "functions.php";

$id = file_get_contents('data/id.txt');
$files = glob("edit/*");

foreach ($files as $file) {
	$f = fopen("text_cn_full/$id.txt", "a+");
	fwrite($f, "\n\n" . file_get_contents($file));
	fclose($f);
}

header('Location: list_get.php');