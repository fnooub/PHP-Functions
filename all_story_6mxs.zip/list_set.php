<?php

include "functions.php";

for ($i = 1; $i <= 46; $i++) {
	$urls[] = 'http://m.6mxs.com/type.asp?id=17&page=' . $i;
}

$multi_curl = multi_curl($urls);

// tach id tat ca truyen
preg_match_all('@<div class="img"><a href=".+?asp\?id=(\d+)">@si', $multi_curl, $links);

	
file_put_contents('data/list_links.txt', json_encode($links[1]));

// chuyen huong
header("Refresh:2; url=list_start.php");
echo "<p>chờ...</p>";